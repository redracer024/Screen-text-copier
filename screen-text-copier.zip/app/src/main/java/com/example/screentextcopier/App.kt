package com.example.screentextcopier

import android.app.Application
import android.content.Intent

class App : Application() {
    companion object {
        var projectionResultCode: Int = 0
        var projectionData: Intent? = null
    }
}
