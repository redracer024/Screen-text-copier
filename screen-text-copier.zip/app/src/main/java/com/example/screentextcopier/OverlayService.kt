package com.example.screentextcopier

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView

class OverlayService : Service() {

    companion object {
        var isRunning = false
        const val CHANNEL_ID = "overlay_channel_01"
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        startForeground(1, buildNotification())

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        if (bubbleView != null) windowManager.removeView(bubbleView)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(CHANNEL_ID, "Overlay Service", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(chan)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        return builder.setContentTitle("Screen Text Copier")
            .setContentText("Floating bubble active - tap to OCR")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
    }

    private fun addBubble() {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        bubbleView = inflater.inflate(R.layout.view_bubble, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params!!.gravity = Gravity.TOP or Gravity.START
        params!!.x = 100
        params!!.y = 200

        val bubbleImg = bubbleView!!.findViewById<ImageView>(R.id.bubble_img)
        bubbleImg.setOnTouchListener(object : View.OnTouchListener {
            var offsetX = 0f
            var offsetY = 0f
            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        offsetX = event.rawX - params!!.x
                        offsetY = event.rawY - params!!.y
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params!!.x = (event.rawX - offsetX).toInt()
                        params!!.y = (event.rawY - offsetY).toInt()
                        windowManager.updateViewLayout(bubbleView, params)
                    }
                    MotionEvent.ACTION_UP -> {
                        // treat as click when small movement
                    }
                }
                return true
            }
        })

        bubbleImg.setOnClickListener {
            // request MainActivity/CaptureService to capture
            val intent = Intent(this, CaptureService::class.java)
            startService(intent)
        }

        windowManager.addView(bubbleView, params)
    }
}
