package com.example.screentextcopier

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var toggleBtn: Button

    private val requestOverlayLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        // no-op; after returning user should enable overlay
        checkOverlayAndStartServiceIfNeeded()
    }

    private val projectionPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            App.projectionResultCode = result.resultCode
            App.projectionData = result.data
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toggleBtn = findViewById(R.id.btn_toggle)
        toggleBtn.setOnClickListener {
            val isRunning = OverlayService.isRunning
            if (isRunning) {
                stopService(Intent(this, OverlayService::class.java))
                toggleBtn.text = "Start Bubble"
            } else {
                ensureOverlayPermissionThenStart()
            }
        }

        // request projection permission upfront so bubble can capture without prompting later
        findViewById<Button>(R.id.btn_req_projection).setOnClickListener {
            requestProjectionPermission()
        }
    }

    override fun onResume() {
        super.onResume()
        toggleBtn.text = if (OverlayService.isRunning) "Stop Bubble" else "Start Bubble"
    }

    private fun ensureOverlayPermissionThenStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            requestOverlayLauncher.launch(intent)
        } else {
            // overlay allowed; ensure projection permission exists (optional)
            startService(Intent(this, OverlayService::class.java))
        }
    }

    private fun requestProjectionPermission() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        val intent = mgr.createScreenCaptureIntent()
        projectionPermissionLauncher.launch(intent)
    }
}
