package com.example.screentextcopier

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "capture_channel_01"
    }

    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(2, buildNotification())
        startCaptureAndOcr()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        imageReader?.close()
        mediaProjection?.stop()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(CHANNEL_ID, "Capture Service", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(chan)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        return builder.setContentTitle("Screen capture")
            .setContentText("Capturing screen for OCR")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
    }

    private fun startCaptureAndOcr() {
        val app = applicationContext as App
        val data = app.projectionData
        val rc = app.projectionResultCode
        if (data == null || rc == 0) {
            // Ask user to allow projection via main activity
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(this, "Grant screen capture permission in app first", Toast.LENGTH_LONG).show()
            }
            stopSelf()
            return
        }

        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(rc, data)
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        wm.defaultDisplay.getMetrics(metrics)
        val density = metrics.densityDpi
        val width = metrics.widthPixels
        val height = metrics.heightPixels

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        val virtualDisplay = mediaProjection!!.createVirtualDisplay("screencap", width, height, density,
            0, imageReader!!.surface, null, null)

        imageReader!!.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width
            val bmp = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buffer)
            image.close()
            reader.close()
            virtualDisplay.release()
            mediaProjection?.stop()

            val screenBitmap = Bitmap.createBitmap(bmp, 0, 0, width, height)
            runOcrAndCopy(screenBitmap)
            stopSelf()
        }, Handler(Looper.getMainLooper()))
    }

    private fun runOcrAndCopy(bitmap: Bitmap) {
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val text = visionText.text
                if (!text.isNullOrBlank()) {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("screenshot_text", text)
                    clipboard.setPrimaryClip(clip)
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(this, "Copied ${text.length} chars to clipboard", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(this, "No text found on screen", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .addOnFailureListener { e ->
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(this, "OCR failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
    }
}
