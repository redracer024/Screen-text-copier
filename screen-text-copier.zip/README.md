Screen Text Copier - Android Studio Project (minimal)
---------------------------------------------------
What this is:
- Minimal Android app that shows a movable floating bubble overlay.
- Tap the bubble to capture the screen, run on-device OCR, and copy the text to clipboard.
- A toggle in the app starts/stops the overlay service.

Notes:
- This project is minimal and intended for personal use. You will need to grant:
  - Display over other apps (SYSTEM_ALERT_WINDOW) via Settings
  - MediaProjection screen-capture permission (system dialog)
- ML Kit dependency version may need updating if build fails. Edit app/build.gradle to adjust versions.
- Tested conceptually; you may need to tweak for your device/Android version.

How to build on Android device:
1. Install AIDE or open in Android Studio on desktop.
2. Import/open this folder as a Gradle Android project.
3. Build and run on a device (allow overlay permission and projection consent).

